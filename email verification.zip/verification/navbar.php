<div class="bg-dark">
<div class ="container">
     <div class="row">
      <div class="col-md-6">
       <nav class="navbar navbar-expand-lg navbar-dark ">
        <div class="container-fluid">
  <a class="navbar-brand" href="#">funda of web IT</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ms-auto mb=4 mb-lg=0">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="Dashboard.php">DashBoard</a>
      </li>

      <?php if (isset($_SESSION['authenticated'])); ?>
      <li class="nav-item active">
        <a class="nav-link" href="register.php">register</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="login.php">login</a>
      </li>
     
      


    </ul>


    </div>
     </div>
</div>
  </div>
</nav>