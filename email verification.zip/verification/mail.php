<?php
$verification_code = bin2hex(random_bytes(16));

$base_url = "http://example.com/";
$url = $base_url . "verify.php?code=" . $verification_code;

$message = "Please click on the following link to verify your email address: " . $url;

$subject = "Email Verification";


$to = "mahek.shekhda166@gmail.com"; 

// Send the email
$mail_sent = mail($to, $subject, $message);

// Check if the email was sent successfully
if ($mail_sent) {
    echo "Email sent successfully!";
} else {
    echo "Failed to send email.";
}
?>
