<?php 
session_start();
if(isset($_SESSION['authenticated']))
{
    $_SESSION['status'] = "you are already logged in";
    header('Location:dashboard.php');
    exit(0);
}


    $page_title = "login form";
     include ('header.php');
     include ('navbar.php'); 
      
?>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-left">
            <div class="col-md-6">

            <?php  
                  if(isset($_SESSION['status']))
                  {
                    ?>
                    <div class="alert alert-success">
                        <h6>= $_SESSION['status']; ?></h6>
                    </div>
                    ?>
                  
                    <?php 
                    unset($_SESSION['status']);
                  }
            ?>
            <h4>Login Form</h4>
            </div>
             <div class="card-header"></div>
            </div>
             <div class="card-body">
            </div>
                <form action="logincode.php" method="POST">
                    <div class="form-group mb-3">
                        <label for="">Email Address</label>
                        <input type="text"name="phone" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Password</label>
                        <input type="text"name="password" class="form-control">
                    </div>
                    <div class="form-group">
                    <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                    <a href="password-reset-php" class="float-end">Forget Your Password?</a>
                </div>
</form>
        <hr>
        <h5>Did not Receive your Verification Email?  
            <a href="resend-email-verification.php">Resend</a>
        </h5>
    </div>
    </div>

<?php include('footer.php'); ?>