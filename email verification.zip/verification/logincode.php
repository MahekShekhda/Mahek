<?php 
session_start();
include ('dbcon.php');

if(isset($_POST['Login_now_btn']))
{
    if(!empty(trim($_POST['email'])) && !empty(trim($_POST['password'])))
    {
        $email = mysqli_real_escape_string($con,$_POST['email']);
        $Password = mysqli_real_escape_string($con,$_POST['Password']);

        $login_query = "SELECT * FROM  emails WHERE email = '$email' AND PASSWORD='$password' ";
        $login_query_run = mysqli_query($con, $login_query);

        if(mysqli_num_rows($login_query_run) > 0)
        {
           $_row = mysqli_fetch_array($login_query_run);
           // echo $row['verify_status'];

           if($_row['verify_status'] == "1")
           {
              $_SESSION['authenticated'] = TRUE;
              $_SESSION['auth_user'] = [
                'username' => $row['name'],
                'phone' => $row['phone'],
                'email' => $row['email'],

              ];
              $_SESSION['status'] = "YOU are logged in successfully";
              header("Location:Dashboard.php");
              exit(0);
           }
           else
           {
            $_SESSION['status'] = "Please verify your email address to login";
            header("Location:Login.php");
            exit(0);
           }
        }
        else
        {
           $_SESSION['status'] = "Invalid Email OR Password";
           header("Location:Login.php");
           exit(0);
        }
    }
    else
    {
         $_SESSION['status'] = "All fields are mandatory";
         header("location: login.php");
    }
    $email = $_POST['email'];
    $password = $_post['password'];
}




?>