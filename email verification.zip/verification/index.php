<?php 
    $page_title = "home page";
     include ('header.php');
     include ('navbar.php'); 
      
?>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h4>Login and Registration in php</h4>
                <h5>with email verification</h5>
            </div>
    </div>
    </div>
<?php include('footer.php'); ?>

