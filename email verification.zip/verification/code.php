<?php
include('config.php');



if (isset($_POST['register_btn'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmpwd = $_POST['confirmpassword'];
    $verification_code = bin2hex(random_bytes(16));


    $base_url = "http://localhost/project/phase_1/verification/login.php";
    $url = $base_url . "verify.php?code=" . $verification_code;

    $message = "Please click on the following link to verify your email address: " . $url;

    $subject = "Email Verification";


    $to = "mahek.shekhda166@gmail.com";

    // Send the email
    $mail_sent = mail($to, $subject, $message);

    //Email Exists or not
    $check_email_query = "Select email FROM emails WHERE email='$email' LIMIT 1";
    $check_email_query_run = mysqli_query($con, $check_email_query);

    if (mysqli_num_rows($check_email_query_run) > 0) {
        $_SESSION['status'] = "Email ID already exists";
        header("Location: register.php");
    } else {
        //Insert user 

        $query = "INSERT INTO emails (name,phone,email,password,confirmpassword,verification_code,is_verified) VALUES ('$name','$phone','$email','$password','$confirmpwd','$verification_code','0')";
        $query_run = mysqli_query($con, $query);



        if ($query_run) {
            // sendmail_verify("$name","$email","$verify_token");
            $_SESSION['status'] = "Registration successfull";
            header("Location: login.php");
        } else {
            $_SESSION['status'] = "Registration failed";
            header("Location: register.php");
        }
    }
}
