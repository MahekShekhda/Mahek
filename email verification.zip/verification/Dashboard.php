<?php 
    include('authentication.php');
    $page_title = "Dashboard";
     include ('header.php');
     include ('navbar.php'); 
      
?>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">

            <?php  
                  if(isset($_SESSION['status']))
                  {
                    ?>
                    <div class="alert alert-success">
                        <h6>= $_SESSION['status']; ?></h6>
                    </div>
                    <?php 
                    unset($_SESSION['status']);
                  }
            ?>
            
               <h4>User Dashboard</h4>
            </div>
            <div class="card-body">
                <h2>ACCESS WHEN YOU ARE LOGGED IN</h2>
                

            </div>
    </div>
    </div>
</div>
<?php include('footer.php'); ?>