<?php 
session_start();
include('dbcon.php');


function resend_email_verify($name,$email,$verify_token)
{
    $mail = new PHPMailer(true);

    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
     $mail->isSMTP();                                            //Send using SMTP
     $mail->Host       = 'smtp.example.com';                     //Set the SMTP server to send through
     $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
     $mail->Username   = 'mahek.shekhda166@example.com';                     //SMTP username
 $mail->Password   = 'secret';                               //SMTP password
 $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
 $mail->Port       = 587;  
 
 $mail->SMTPSecure = "tls";
 $mail->addAddress($email);

 $email->setfrom("mahek.shekhda166@gmail.com",$name);
 $mail->addAddress($email);
 
 $mail->setFrom("mahek.shekhda166@gmail.com",$name);
 $mail->addAddress($email);

 $mail->isHTML(true);
 $mail->Subject = "Email Verification from Funda of Web IT";
}


 
 



if(isset($_POST['resend_email_verify_btn']))
{
     if(!empty(trim($_POST['email'])))
     {
        $email =  mysqli_real_escape_string($con, $_POST['email']);

        $checkmail_query = "SELECT * FROM emails WHERE email='$email' LIMIT 1";
        $checkmail_query_run = mysqli_query($con,$checkmail_query);

        if(mysqli_num_rows( $checkmail_query_run) > 0)
        {
            $row = mysqli_fetch_array($checkmail_query_run);
            if($row['verify_status' == "0"])
            {
                 $name = $row['name'];
                 $email= $row['email'];
                 $verify_token = $row['verify_token'];

                 resend_email_verify($name,$email,$verify_token);
                 $_SESSION['status'] = "verification email link has been sent to your email address.!";
                 header("Location: login.php");
                 exit(0);
            }
            else{
                $_SESSION['status'] = "Email already verified.please login";
                header("Location: resend-email-verification.php");
                exit(0);
            }
        }
        else
        {
            $_SESSION['status'] = "Email is not registered.please register now.!";
            header("Location: register.php");
            exit(0);
        }
     }
     else
     {
       $_SESSION['status'] = "please enter the mail field";
       header("Location: resend-email-verification.php");
       exit(0);
     } 
}


?>